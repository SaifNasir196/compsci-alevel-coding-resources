# using lists
# ----------------------------------

Data  = ['e','b','c','','','','','','']
pointer = [-1,2,0,4,5,6,0,1,7,8]
start_ptr = 1
free_ptr = 3

def linked_lst():
    current = start_ptr
    if current == -1:
        return 'empty list'
    while current!=-1:
        print(Data[current])
        current = pointer[current]

# linked_lst()


def insert_at_start(item, Data, pointer):
    global start_ptr, free_ptr
    new_node_ptr = free_ptr
    Data[new_node_ptr] = item
    free_ptr = pointer[free_ptr]

    pointer[new_node_ptr] = start_ptr
    start_ptr = new_node_ptr
insert_at_start('a', Data, pointer)

# linked_lst()

def insert(item, start):
    global free_ptr
    new_node = free_ptr
    Data[new_node]= item
    free_ptr = pointer[new_node]
    current = start
    
    while Data[current] < item:
        previous_ptr = current
        current = pointer[current]
    
    if current == start:
        pointer[new_node] = start
        start = new_node
    else:
        pointer[new_node] = pointer[previous_ptr]
        pointer[previous_ptr] = new_node

insert('d',start_ptr)


linked_lst()
print(Data)